
export const environment = {
  production: true,
  API: 'http://youdomain:3000'
};
