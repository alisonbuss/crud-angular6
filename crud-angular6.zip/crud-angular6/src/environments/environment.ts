
export const environment = {
  production: false,
  API: 'http://localhost:3000'
};
