
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-test',
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

    public valorAtual: string = "";
    public valorSalvo: string = "";
    public isMouseOver: boolean = false;

    nome: string = "Abc...";

    constructor() {
        console.log("AAAA");
    }

    ngOnInit() {
        console.log("BBBB");
        console.log(this);
    }

    onClickBtn() {
        console.log(this);
        alert("Evento Click no Botão");
    }

    onKeyUp(event: KeyboardEvent) {
        console.log(event);
        this.valorAtual = (<HTMLInputElement>event.target).value;
    }

    onKeyUpSave(value: string) {
        console.log(value);
        this.valorSalvo = value;
    }

    onMouseOverOut(): void {
        console.log(this.isMouseOver);
        this.isMouseOver = !this.isMouseOver;
    }

}
